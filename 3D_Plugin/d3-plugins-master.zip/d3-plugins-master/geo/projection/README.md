Moved to [d3-geo-projection](https://github.com/d3/d3-geo-projection/).
