# d3.hive

A plugin for rendering Hive Plots. Example:

<http://bost.ocks.org/mike/hive/>
