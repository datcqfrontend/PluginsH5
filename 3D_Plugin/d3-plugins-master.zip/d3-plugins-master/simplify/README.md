# Line Simplification

Deprecated; replaced with [TopoJSON](https://github.com/mbostock/topojson).
