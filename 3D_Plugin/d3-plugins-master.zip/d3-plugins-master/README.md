# D3 Plugins

Please note: the plugins in this repository will soon be broken up into separate repositories for easier distributed ownership. If you have a new plugin you’d like to share, please add a link to it from the [D3 plugins wiki](https://github.com/mbostock/d3/wiki/Plugins).
